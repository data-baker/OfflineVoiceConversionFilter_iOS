//
//  Created by xianing on 2021/7/27.
//  Copyright © 2021 Agora Corp. All rights reserved.
//

#import <Foundation/Foundation.h>


//! Project version number for SimpleFilter.
FOUNDATION_EXPORT double SimpleFilterVersionNumber;

//! Project version string for SimpleFilter.
FOUNDATION_EXPORT const unsigned char SimpleFilterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SimpleFilter/PublicHeader.h>

#import <DataBakerOfflineVC/DBVoiceConvertFilterManager.h>
