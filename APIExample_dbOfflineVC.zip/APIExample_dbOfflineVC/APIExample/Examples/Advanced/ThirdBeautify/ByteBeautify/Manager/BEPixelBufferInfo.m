//
//  BEPixelBufferInfo.m
//  BeautifyExample
//
//  Created by zhaoyongqiang on 2022/8/19.
//  Copyright © 2022 Agora. All rights reserved.
//

#import "BEPixelBufferInfo.h"

@implementation BEPixelBufferInfo

@end
