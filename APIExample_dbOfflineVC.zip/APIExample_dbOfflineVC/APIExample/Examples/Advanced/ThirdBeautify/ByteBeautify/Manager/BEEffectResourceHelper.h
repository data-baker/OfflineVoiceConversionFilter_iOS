//
//  BEEffectResourceHelper.h
//  Effect
//
//  Created by qun on 2021/5/18.
//

#ifndef BEEffectResourceHelper_h
#define BEEffectResourceHelper_h

#import <Foundation/Foundation.h>
#import "BEEffectManager.h"

@interface BEEffectResourceHelper : NSObject<BEEffectResourceProvider>

@end

#endif /* BEEffectResourceHelper_h */
