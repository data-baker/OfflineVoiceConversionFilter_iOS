//
//  FUBeautify.h
//  APIExample
//
//  Created by zhaoyongqiang on 2022/10/21.
//  Copyright © 2022 Agora Corp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FUBeautifyVC : UIViewController

@property (nonatomic, strong) NSDictionary *configs;

@end
